export enum WebServiceUrls {
    GET_ALL_COUNTRY_NAMES_WITH_ALPHACODE = "https://restcountries.eu/rest/v2/all?fields=name;alpha3Code"
}