export class Country {
    name: string
    alpha3Code:string
}